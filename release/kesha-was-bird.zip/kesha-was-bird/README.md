Good day!

We're slightly deranged and we thought that it was new octojam, not awful jam.
Seeing first pico8 game was kinda surprising, but we had courage to finish and
polish our game anyway.

This game works best with 1000 i/f, but should work with default 20i/f settings.
We use XO-extensions such as audio and extended memory addressing.

We also believe that this game is one of the biggest chip8 games ever created.
We hope you will like it.

The recommented palette is:

BG	59755E
FG1	B8CD9E
FG2	ED656B
BL	55989E
BZ	000000
SL	000000

Copy-pasting game.txt into emulator source window should give you working game.

The language in this game is kind of quirky. We ain't native speakers, sorry.
Game contains a bit of gore with fine finish of 1-pixel erotic.

Please find working gist there:

http://johnearnest.github.io/Octo/index.html?gist=75b2da4b0820c49b1412

Please don't hesitate to contact me if you have any further questions:
vladimir.menshakov@gmail.com

Please write me if you want to take a peek into the source code.
We plan to release full source code to github a little bit later.
